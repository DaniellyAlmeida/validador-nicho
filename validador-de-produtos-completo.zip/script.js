
function checkPassword() {
  const senha = document.getElementById("password").value;
  if (senha === "Pdrx2025") {
    document.getElementById("login-screen").style.display = "none";
    document.getElementById("main-content").style.display = "block";
  } else {
    document.getElementById("error-message").innerText = "Chave incorreta, tente novamente";
  }
}

function validarNicho() {
  const nicho = document.getElementById("nicho").value.trim().toLowerCase();
  const resultado = document.getElementById("resultado-nicho");
  if (!nicho) return resultado.innerText = "Digite um nicho válido.";
  resultado.innerText = `O nicho "${nicho}" apresenta volume de busca estável e tendência de crescimento.`;
}

function avaliarProduto() {
  const produto = document.getElementById("produto").value.trim();
  const resultado = document.getElementById("resultado-produto");
  if (!produto) return resultado.innerText = "Digite o nome do produto.";
  resultado.innerText = `O produto "${produto}" tem boa aceitação, concorrência média e potencial de lucro. Nota 8.6/10.`;
}

function gerarPDF() {
  alert("Simulação: Geração de PDF com plano do produto ainda não implementada.");
}
